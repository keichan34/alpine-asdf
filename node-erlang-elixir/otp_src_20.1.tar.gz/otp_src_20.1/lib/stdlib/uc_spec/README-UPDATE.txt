When updating the unicode version copy the necessary files to this
directory.

And update the test files in stdlib/test/unicode_util_SUITE_data/*

Update the spec_version(..) function in the generator,
gen_unicode_mod.escript
